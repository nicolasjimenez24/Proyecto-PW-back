package com.example.pasteleria.ex;

public class BenfitException extends RuntimeException {

    public BenfitException(String message) {
        super(message);
    }
}
