package com.example.pasteleria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PasteleriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
